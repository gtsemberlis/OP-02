#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, shutil, subprocess, sys
from pathlib import Path
from bs4 import BeautifulSoup
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
THEME = ROOT / 'theme'
DIST = ROOT / 'dist'
REPORTS = ROOT / 'reports'


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def normalize_source(text: str) -> tuple[str, dict]:
    # The uploaded editorial master contains an early preserved draft followed by
    # the canonical YAML release and then reconstruction material. Publish only
    # the declared Canonical Manuscript release, without altering the source file.
    marker = '---\ntitle: "OP-01: Operation Airspace"'
    start = text.find(marker)
    if start < 0:
        raise ValueError('Canonical YAML release marker not found.')
    canonical = text[start:]
    end_marker = '\n# Chapter Two\n## Program Briefing'
    end = canonical.find(end_marker)
    if end >= 0:
        canonical = canonical[:end].rstrip() + '\n'

    yaml_end = canonical.find('\n---', 4)
    if yaml_end < 0:
        raise ValueError('YAML front matter is not closed.')
    yaml_block = canonical[4:yaml_end]
    body = canonical[yaml_end + 4:].lstrip()

    metadata = {}
    for line in yaml_block.splitlines():
        if ':' in line:
            k, v = line.split(':', 1)
            metadata[k.strip()] = v.strip().strip('"')

    # Cover is supplied by the publication template.
    op_heading = '# OP-01: Operation Airspace'
    overview = '# Operation Overview'
    idx = body.find(overview)
    if idx < 0:
        raise ValueError('Operation Overview heading not found.')
    body = body[idx:]

    # The hand-authored Contents list is superseded by the generated linked TOC.
    body = re.sub(r'^# Contents\n.*?(?=^# Operation Overview)', '', body, flags=re.M | re.S)
    normalized = '---\n' + yaml_block + '\n---\n\n' + body.strip() + '\n'
    return normalized, metadata


def enhance_html(html_path: Path) -> dict:
    """Add publication-level navigation without changing manuscript prose."""
    soup = BeautifulSoup(html_path.read_text(encoding='utf-8'), 'html.parser')
    article = soup.select_one('article')
    if not article:
        raise ValueError('Published article element not found.')

    # Mark chapters and appendices for distinct print/HTML treatment.
    chapter_count = 0
    appendix_count = 0
    for section in article.find_all('section', recursive=False):
        heading = section.find(['h1', 'h2'], recursive=False)
        if not heading:
            continue
        title = heading.get_text(' ', strip=True)
        if title.startswith('Scene '):
            section['class'] = list(section.get('class', [])) + ['chapter-section']
            chapter_count += 1
        elif title.startswith('Appendix '):
            section['class'] = list(section.get('class', [])) + ['appendix-section']
            appendix_count += 1

    # Build a text-to-anchor map for major sections. This enables useful links
    # inside timelines and indexes while leaving normal prose untouched.
    anchors = {}
    for heading in article.find_all(['h1', 'h2']):
        target = heading.get('id')
        if not target and heading.parent and heading.parent.name == 'section':
            target = heading.parent.get('id')
        if target:
            text = heading.get_text(' ', strip=True)
            anchors[text] = target
            m = re.match(r'^(Scene\s+\d+)', text)
            if m:
                anchors[m.group(1)] = target
            m = re.match(r'^(Appendix\s+[A-Z])', text)
            if m:
                anchors[m.group(1)] = target

    auto_links = 0
    for table in article.find_all('table'):
        for cell in table.find_all(['td', 'th']):
            # Link exact or compact scene/appendix labels used by the manuscript's indexes.
            for node in list(cell.find_all(string=True, recursive=True)):
                if node.parent.name == 'a':
                    continue
                value = str(node)
                pattern = re.compile(r'\b(Scene\s+\d+|Appendix\s+[A-Z])\b')
                parts = pattern.split(value)
                if len(parts) == 1:
                    continue
                for part in parts:
                    if part in anchors:
                        a = soup.new_tag('a', href=f'#{anchors[part]}')
                        a['class'] = ['index-link']
                        a.string = part
                        node.insert_before(a)
                        auto_links += 1
                    elif part:
                        node.insert_before(part)
                node.extract()

    # Add a quiet return link to each major section for long-form HTML reading.
    return_links = 0
    for heading in article.find_all('h1'):
        back = soup.new_tag('a', href='#cover')
        back['class'] = ['back-to-contents']
        back.string = 'Return to contents'
        heading.insert_after(back)
        return_links += 1

    html_path.write_text(str(soup), encoding='utf-8')
    return {
        'chapter_sections': chapter_count,
        'appendix_sections': appendix_count,
        'generated_index_links': auto_links,
        'return_links': return_links,
    }


def flatten_outline(items):
    out = []
    for item in items:
        if isinstance(item, list):
            out.extend(flatten_outline(item))
        else:
            try:
                out.append(str(item.title))
            except Exception:
                out.append(str(item))
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description='Build the Canonical Manuscript reading edition.')
    ap.add_argument('source', type=Path)
    ap.add_argument('--basename', default='OP-01_Canonical_Manuscript_v1.0_CMP4')
    args = ap.parse_args()
    DIST.mkdir(exist_ok=True); REPORTS.mkdir(exist_ok=True)

    raw = args.source.read_text(encoding='utf-8')
    normalized, meta = normalize_source(raw)
    normalized_path = DIST / f'{args.basename}_NORMALIZED.md'
    normalized_path.write_text(normalized, encoding='utf-8')

    css = (THEME / 'canonical.css').read_text(encoding='utf-8')
    template = (THEME / 'template.html').read_text(encoding='utf-8')
    html_path = DIST / f'{args.basename}.html'
    pdf_path = DIST / f'{args.basename}.pdf'

    cmd = [
        'pandoc', str(normalized_path), '--from', 'markdown+smart', '--to', 'html5',
        '--standalone', '--toc', '--toc-depth=2', '--section-divs',
        '--template', str(THEME / 'template.html'),
        '--metadata', f'title={meta.get("title", "Operation Airspace")}',
        '--metadata', 'edition=Canonical Manuscript',
        '--metadata', f'version={meta.get("version", "1.0")}',
        '--metadata', f'classification={meta.get("operation_classification", "YELLOW")}',
        '--variable', f'css={css}', '--output', str(html_path)
    ]
    run(cmd)

    # Add a print-only contents page without duplicating HTML anchor IDs.
    soup = BeautifulSoup(html_path.read_text(encoding='utf-8'), 'html.parser')
    nav = soup.select_one('.book-nav details > ul')
    publication_page = soup.select_one('.publication-page')
    if nav and publication_page:
        print_toc = soup.new_tag('section', attrs={'class': 'print-toc'})
        title = soup.new_tag('h1')
        title.string = 'Contents'
        print_toc.append(title)
        cloned = BeautifulSoup(str(nav), 'html.parser').ul
        for node in cloned.find_all(attrs={'id': True}):
            del node['id']
        print_toc.append(cloned)
        publication_page.insert_after(print_toc)
        html_path.write_text(str(soup), encoding='utf-8')

    enhancements = enhance_html(html_path)
    run(['weasyprint', str(html_path), str(pdf_path)])

    soup = BeautifulSoup(html_path.read_text(encoding='utf-8'), 'html.parser')
    ids = {tag.get('id') for tag in soup.find_all(attrs={'id': True})}
    internal = [a.get('href') for a in soup.find_all('a', href=True) if a.get('href','').startswith('#')]
    broken = sorted({h for h in internal if h[1:] not in ids})
    headings = {f'h{i}': len(soup.find_all(f'h{i}')) for i in range(1,4)}
    reader = PdfReader(str(pdf_path))
    page_sizes = []
    for p in reader.pages:
        w = round(float(p.mediabox.width), 2); h = round(float(p.mediabox.height), 2)
        page_sizes.append([w, h])
    unique_page_sizes = sorted({tuple(x) for x in page_sizes})
    letter_size_ok = unique_page_sizes == [(612.0, 792.0)]
    pdf_text = '\n'.join((p.extract_text() or '') for p in reader.pages)
    outline_titles = flatten_outline(reader.outline)
    annotation_links = 0
    for page in reader.pages:
        annots = page.get('/Annots', [])
        annotation_links += len(annots)
    required = ['Operation Overview', 'Scene 1', 'Scene 9', 'Appendix A', 'Canonical Release Declaration']
    missing_text = [x for x in required if x not in pdf_text]
    report = {
        'publisher': 'Canonical Manuscript Publisher',
        'milestone': 'CMP-4',
        'source': args.source.name,
        'normalized_source': normalized_path.name,
        'outputs': {'html': html_path.name, 'pdf': pdf_path.name},
        'html': {'headings': headings, 'internal_links': len(internal), 'broken_internal_links': broken, **enhancements},
        'pdf': {'pages': len(reader.pages), 'page_sizes_points': [list(x) for x in unique_page_sizes], 'letter_size_ok': letter_size_ok, 'missing_required_text': missing_text, 'bookmarks': len(outline_titles), 'bookmark_titles': outline_titles, 'link_annotations': annotation_links, 'running_headers_enabled': True, 'duplex_mirrored_margins': True, 'recto_chapter_starts': True, 'letter_print_profile': True, 'minimal_cover': True, 'dedicated_chapter_openers': True, 'typography_polish': True},
        'canonical_segment': {'duplicate_reconstruction_material_excluded': True},
        'status': 'PASS' if not broken and not missing_text and letter_size_ok else 'FAIL'
    }
    report_path = DIST / f'{args.basename}_BUILD_REPORT.json'
    report_path.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
    return 0 if report['status'] == 'PASS' else 1

if __name__ == '__main__':
    raise SystemExit(main())
