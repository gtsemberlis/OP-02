# Canonical Manuscript Publisher v1.0 - CMP-4

CMP-4 is the editorial polish release. It preserves the canonical manuscript while refining the reading and print editions through quieter typography, dedicated section openers, and a simplified publication structure.

## Features

- Minimal typographic cover with no quotation, classification badge, or decorative frame
- Dedicated publication-information page
- Responsive single-file HTML reading edition
- Letter-size print-ready PDF
- Duplex-friendly mirrored inner and outer margins
- Dedicated title pages for scenes and appendices
- Refined running heads and page-number placement
- Linked table of contents with PDF page references
- PDF bookmarks for chapters and subsections
- Lighter tables with improved spacing and alignment
- Improved widow, orphan, heading, and table safeguards
- Publication colophon
- Build QA for canonical sections, links, bookmarks, annotations, and page dimensions

## Build

```bash
python publisher/build.py examples/OP-01_Canonical_Manuscript_v1.0.md
```

Outputs are written to `dist/`.
